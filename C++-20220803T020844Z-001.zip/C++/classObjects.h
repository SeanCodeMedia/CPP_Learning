
# include <iostream>
# include <string> 
//# include "mainClass.h"

using namespace std;


class classObject {

   

   void printName ();


  // instnaceOfclass* mainClass; 


};
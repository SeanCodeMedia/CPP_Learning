
#include "iostream"
#include "string"
 
using namespace std; 


int main () {

    int a = 0; 

   cout << &a << endl; //&  adress operator. //* memory pointer operator 


return 0; 
} 
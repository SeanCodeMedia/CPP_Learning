
#include "person.h"
#include <iostream>
#include  "string" 

using namespace std; 

// :: this is the urnary scope resolution  operator

person::person () {


cout << "New Object has just been created" << endl;


}

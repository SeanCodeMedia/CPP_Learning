
#include <iostream>
#include "string"
#include "person.h"

using namespace std; 


int main () {

 
 person person01;


 
 return 0; 
}
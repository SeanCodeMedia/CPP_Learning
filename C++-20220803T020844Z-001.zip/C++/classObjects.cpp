

# include <iostream>
# include <string>
//# include "classObjects.h"

using namespace std;

   void classObjects::printName () {

     cout << "MY name is sean" << endl;
 

   }
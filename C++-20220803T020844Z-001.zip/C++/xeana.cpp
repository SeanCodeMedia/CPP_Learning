
#include <iostream> 

using namespace std; 


class xeana {
  
 
void phone () {

 cout << "I am xeana and I like to use my phone "  << endl; 

}


void figthing () {

  cout << "I like to fight people " << endl; 

}


void talk () {


  cout << "I like to talk alot " << endl; 


}


void likePic () {

 cout << "I like to take pictures" << endl; 

}

 
 void likeFacebook () {

 cout << "I am xeana and I  like facebook" << endl; 

 }


  void likeDisney () {
  
  cout << "I like to watch disney" << endl; 
   

  }

}; 



int main () {



} 
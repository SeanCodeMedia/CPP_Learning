# include <iostream> 
# include "stdio"
# include "cmath"
# include "string" 


using namespace std; 


class cupcake () {
 
 private: 

 int numberOfcupCake = 0; 

 public: 
   

} 




int main  () {
    

    printf("works");


	 return 0; 
}

#ifndef PERSON_H
#define PERSON_H


class person {
public:
	person();
	
};

#endif // PERSON_H


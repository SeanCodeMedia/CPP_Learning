
# include <iostream>
# include <string>
# include "classObjects.h"

using namespace std;


int main () {
     

   ob* classObject = new classObject; 

   ob -> printName();


	return 0;
}

#include "iostream"
# include "string"

using namespace std; 



int main () {

    int number = 0;
     number++;

    do {
       

       cout << "cycle  " << number << endl; 

       number++;


    }while ( number <= 100);


   

  
  return 0; 
}
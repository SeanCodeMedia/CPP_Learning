

#ifndef IMPORTS_H
#define IMPORTS_H

#include <SDL.h>
#include <SDL_mixer.h>
#include <SDL_image.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <SDL_ttf.h>

#endif // DEBUG


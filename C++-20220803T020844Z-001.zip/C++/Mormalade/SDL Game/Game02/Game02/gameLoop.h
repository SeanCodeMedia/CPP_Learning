
#pragma once

#ifndef GAMELOOP_H
#define GAMELOOP_H


class gameLoop {

public: 


	void GameLoop();




};





#endif 

#pragma once
class random
{
public:
	random(int  maxNum);
	float mathRandom();
	~random();

private:

	int holdNumber;
	int maxNumber;

};



#include <SDL.h>

#include <SDL_image.h>

#include <SDL_mixer.h>